import Image;
import ImageOps;
import os;
from dominate import document;
from dominate.tags import *;

listaNazw = []
try:
    pliki = os.listdir(r"work");
    for plik in pliki:
        print(plik)
except:
    print("blad")
    exit()

for plik in pliki:
    if plik.endswith(".jpg"):
        obraz = Image.open("work/"+plik).convert('LA').rotate(180)
        obraz = ImageOps.fit(obraz,(125,125),Image.ANTIALIAS)
        nazwa = "work/"+plik+"wynik.png"
        listaNazw.append(nazwa)
        obraz.save(nazwa)

with document(title="zdjecia") as doc:
    h1("Zdjecia")
    for nazwa in listaNazw:
        div(img(src=nazwa),_class="photo")

f = open('work/galeria.html','w')
f.write(doc.render())
f.close()